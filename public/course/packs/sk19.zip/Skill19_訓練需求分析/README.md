# Skill 19｜訓練需求分析

## 檔案
- AGENTS.md
- SKILL.md
- data.csv
- data.xlsx
- README.md

## 💻 有電腦（Codex、Antigravity、Claude）
1. 解壓縮到桌面。
2. 把自己的資料放進 input/（姓名先改成代號，例如 A01）。
3. 用 Codex 或 Antigravity 開啟這個資料夾，輸入：「請依照 SKILL.md 執行」。

## 📱 只有手機（ChatGPT、Gemini App）
1. 打開 App，按「＋」上傳「手機版.md」和範例資料。
2. 輸入：「請依照這份檔案執行」。沒看到檔案就輸入「給我 CSV」。

Excel 的「正確答案」工作表只供人員驗算，請勿上傳給 AI。

---
© 2026 彰化基督教醫院 AI 研習教材｜示範資料皆為虛構｜僅供院內教育訓練使用
