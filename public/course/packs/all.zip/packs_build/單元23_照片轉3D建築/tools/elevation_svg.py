"""建築細節 JSON → 立面座標尺寸 SVG（單位：公尺；原點＝立面左下角，x 向右、y 向上）
用法：python3 tools/elevation_svg.py output/建築細節_admin_hall.json output/立面_admin_hall.svg
"""
import json, sys, html

def fmt(v): return f'{v:.2f}'.rstrip('0').rstrip('.')

def build(data):
    e = data['elevation']; W, H = e['width'], e['height']; S = 30            # 1 m = 30 px
    M = 70; PW, PH = W * S + M * 2 + 170, (H + e.get('parapet_h', 0)) * S + M * 2 + 60
    X = lambda x: M + x * S                                                 # 公尺 → SVG x
    Y = lambda y: PH - M - 30 - y * S                                       # 公尺 → SVG y（翻轉）
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {PW:.0f} {PH:.0f}" font-family="Noto Sans TC, Microsoft JhengHei, sans-serif" font-size="12">',
         '<style>.dim{stroke:#c2410c;stroke-width:1}.dimt{fill:#c2410c;font-size:12px}.grid{stroke:#9ca3af;stroke-width:.4}.est{stroke-dasharray:5 3}</style>',
         f'<rect width="100%" height="100%" fill="#fff"/>',
         f'<text x="{M}" y="26" font-size="16" font-weight="700" fill="#243A35">{html.escape(data["name"]["value"] or "未命名建築")}｜正立面座標尺寸圖（推估）</text>',
         f'<text x="{M}" y="44" fill="#6b7280">原點＝立面左下角；單位 m；比例尺 {html.escape(data["math"]["scale"]["method"])}；誤差約 {html.escape(data["math"]["scale"]["uncertainty"])}</text>']
    o.append(f'<line x1="{X(-1)}" y1="{Y(0)}" x2="{X(W + 1)}" y2="{Y(0)}" stroke="#374151" stroke-width="2"/>')
    o.append(f'<rect x="{X(0)}" y="{Y(H)}" width="{W * S}" height="{H * S}" fill="#e8e0cf" stroke="#374151" stroke-width="1.5"/>')
    for i in range(0, int(W) + 1):                                         # 1 m 格線
        o.append(f'<line class="grid" opacity=".6" x1="{X(i)}" y1="{Y(0)}" x2="{X(i)}" y2="{Y(H)}"/>')
        if i % 2 == 0: o.append(f'<text x="{X(i)}" y="{Y(0) + 16}" text-anchor="middle" fill="#6b7280">{i}</text>')
    for j in range(0, int(H) + 1):
        o.append(f'<line class="grid" opacity=".6" x1="{X(0)}" y1="{Y(j)}" x2="{X(W)}" y2="{Y(j)}"/>')
        if j % 2 == 0: o.append(f'<text x="{X(0) - 8}" y="{Y(j) + 4}" text-anchor="end" fill="#6b7280">{j}</text>')
    ph = e.get('parapet_h', 0)
    if ph: o.append(f'<rect x="{X(0)}" y="{Y(H + ph)}" width="{W * S}" height="{ph * S}" fill="#cfc6b3" stroke="#374151"/>')
    w = e['windows']; skip = {tuple(s) for s in w.get('skip', [])}; n = 0
    for r, y0 in enumerate(w['row_y']):
        hh = w['h'][r] if isinstance(w['h'], list) else w['h']
        for c in range(w['cols']):
            if (r, c) in skip: continue
            x0 = w['x0'] + c * w['dx']; n += 1
            o.append(f'<rect x="{X(x0):.1f}" y="{Y(y0 + hh):.1f}" width="{w["w"] * S:.1f}" height="{hh * S:.1f}" fill="#5b7fa3"/>')
    for k in ('canopy', 'door', 'sign'):
        if k not in e: continue
        b = e[k]; fill = {'canopy': '#9aa3ad', 'door': '#334155', 'sign': '#283446'}[k]
        o.append(f'<rect x="{X(b["x"]):.1f}" y="{Y(b["y"] + b["h"]):.1f}" width="{b["w"] * S:.1f}" height="{b["h"] * S:.1f}" fill="{fill}"/>')
        if k == 'sign' and b.get('text'): o.append(f'<text x="{X(b["x"] + b["w"] / 2):.1f}" y="{Y(b["y"] + b["h"] / 2) + 6:.1f}" text-anchor="middle" fill="#fff" font-size="{b["h"] * S * 0.55:.0f}" font-weight="700">{html.escape(b["text"])}</text>')
        o.append(f'<text x="{X(b["x"]):.1f}" y="{Y(b["y"] + b["h"]) - 4:.1f}" class="dimt" font-size="10">({fmt(b["x"])}, {fmt(b["y"])}) {fmt(b["w"])}×{fmt(b["h"])}</text>')
    def dim_h(x1, x2, y, label):
        o.append(f'<line class="dim" x1="{X(x1)}" y1="{y}" x2="{X(x2)}" y2="{y}"/><line class="dim" x1="{X(x1)}" y1="{y - 5}" x2="{X(x1)}" y2="{y + 5}"/><line class="dim" x1="{X(x2)}" y1="{y - 5}" x2="{X(x2)}" y2="{y + 5}"/>')
        o.append(f'<text class="dimt" x="{(X(x1) + X(x2)) / 2}" y="{y - 4}" text-anchor="middle">{label}</text>')
    def dim_v(y1, y2, x, label):
        o.append(f'<line class="dim" x1="{x}" y1="{Y(y1)}" x2="{x}" y2="{Y(y2)}"/><line class="dim" x1="{x - 5}" y1="{Y(y1)}" x2="{x + 5}" y2="{Y(y1)}"/><line class="dim" x1="{x - 5}" y1="{Y(y2)}" x2="{x + 5}" y2="{Y(y2)}"/>')
        o.append(f'<text class="dimt" x="{x + 6}" y="{(Y(y1) + Y(y2)) / 2 + 4}">{label}</text>')
    dim_h(0, W, Y(0) + 36, f'W ≈ {fmt(W)} m（推估）')
    dim_v(0, H, X(W) + 18, f'H ≈ {fmt(H)} m')
    fl = e.get('floor_lines', [])
    for i, (a, b) in enumerate(zip([0] + fl, fl + [H])): dim_v(a, b, X(W) + 90, f'{i + 1}F {fmt(b - a)}')
    dim_h(w['x0'], w['x0'] + w['dx'], Y(w['row_y'][-1]) + 14, f'窗距 d={fmt(w["dx"])}')
    o.append(f'<text x="{M}" y="{PH - 12}" fill="#6b7280">窗戶 {n} 扇（等差數列 xᵢ = {fmt(w["x0"])} + i·{fmt(w["dx"])}）｜虛構練習資料・僅供院內教育訓練使用</text></svg>')
    return '\n'.join(o)

if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]
    open(dst, 'w', encoding='utf-8').write(build(json.load(open(src, encoding='utf-8'))))
    print('已輸出', dst)
